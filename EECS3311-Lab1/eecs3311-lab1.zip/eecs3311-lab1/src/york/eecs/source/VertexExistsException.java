package york.eecs.source;

/**
 * This is the exception class
 * @author wangs
 *
 */
public class VertexExistsException extends Exception{
	
	public VertexExistsException(String msg) {
		super(msg);
	}
	
}